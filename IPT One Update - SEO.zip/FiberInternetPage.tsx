
import React from 'react';
import { CheckCircle, Zap, Shield, Server, Home, Building, Globe, MapPin, ArrowRight, Activity, Wifi } from './components/icons';
import ServiceInquiryForm from './ServiceInquiryForm';
import CoverageCheckForm from './CoverageCheckForm';
import CtaSection from './components/CtaSection';
import { useNavigation } from './NavigationContext';
import { connectivityCategory } from './servicesData';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './components/Card';
import { Button } from './components/Button';

const FiberInternetPage: React.FC = () => {
  const navigate = useNavigation();
  const fiberService = connectivityCategory?.subServices?.find(s => s.path === '/connectivity/fiber-internet');

  // Categorize services for better display
  const partnerServices = fiberService?.subServices?.filter(s => s.name.includes('MTN') || s.name.includes('Vodacom')) || [];
  const useCaseServices = fiberService?.subServices?.filter(s => !s.name.includes('MTN') && !s.name.includes('Vodacom')) || [];

  return (
    <>
      {/* Reimagined Hero Section - Matches Web Hosting Page structure */}
      <section className="relative pt-20 pb-24 lg:pt-32 lg:pb-40 overflow-hidden bg-gray-900 text-white">
        {/* Background Effects */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
            <div className="absolute top-[-20%] right-[-10%] w-[800px] h-[800px] bg-brand-blue/20 rounded-full blur-[120px]"></div>
            <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-brand-green/10 rounded-full blur-[100px]"></div>
            {/* Fiber Light Trails Pattern */}
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
            
            <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
                {/* Content */}
                <div className="text-left">
                    <div className="inline-flex items-center space-x-2 bg-cyan-900/30 backdrop-blur-md rounded-full px-4 py-1.5 text-sm font-medium text-cyan-300 border border-cyan-500/30 mb-8">
                        <Zap className="w-4 h-4" />
                        <span>Gigabit Speeds Available</span>
                    </div>

                    <h1 className="text-5xl lg:text-7xl font-extrabold leading-tight mb-6 tracking-tight">
                        Speed of <br/>
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-brand-green">Light.</span>
                    </h1>
                    
                    <p className="text-lg text-gray-300 mb-10 max-w-xl leading-relaxed">
                        Upgrade to the ultimate connectivity standard. Uncapped, unshaped, and symmetrical fibre internet delivering low-latency performance for your home and business.
                    </p>

                    <div className="flex flex-col sm:flex-row gap-4">
                        <Button 
                            size="lg" 
                            onClick={() => navigate('/coverage-check')}
                            className="font-bold text-lg bg-cyan-500 text-gray-900 hover:bg-white border-transparent shadow-[0_0_30px_rgba(6,182,212,0.3)]"
                        >
                            <MapPin className="w-5 h-5 mr-2" />
                            Check Coverage
                        </Button>
                        <Button 
                            size="lg" 
                            variant="outline" 
                            className="font-bold text-lg text-white border-gray-600 hover:bg-gray-800 hover:border-white"
                            onClick={() => document.getElementById('packages')?.scrollIntoView({ behavior: 'smooth' })}
                        >
                            View Packages
                        </Button>
                    </div>
                    
                    <div className="mt-12 pt-8 border-t border-gray-800 grid grid-cols-3 gap-4 text-gray-400 text-sm font-medium">
                        <div>
                            <p className="text-3xl font-bold text-white">1<span className="text-sm text-cyan-400 ml-1">Gbps</span></p>
                            <p className="text-xs uppercase tracking-wider mt-1">Max Speed</p>
                        </div>
                        <div>
                            <p className="text-3xl font-bold text-white">99<span className="text-sm text-brand-green ml-1">%</span></p>
                            <p className="text-xs uppercase tracking-wider mt-1">Uptime SLA</p>
                        </div>
                        <div>
                            <p className="text-3xl font-bold text-white">20<span className="text-sm text-gray-400 ml-1">+</span></p>
                            <p className="text-xs uppercase tracking-wider mt-1">Networks</p>
                        </div>
                    </div>
                </div>

                {/* Visual */}
                <div className="relative lg:h-[600px] flex items-center justify-center">
                    <div className="relative w-full max-w-md perspective-1000">
                        {/* Glowing Fiber Core Graphic */}
                        <div className="absolute inset-0 bg-cyan-500/20 blur-[100px] rounded-full -z-10"></div>
                        
                        <div className="relative z-20 bg-gray-800/80 backdrop-blur-xl border border-gray-700 rounded-3xl p-8 shadow-2xl overflow-hidden transform hover:scale-[1.02] transition-transform duration-500">
                            {/* Speedometer Simulation */}
                            <div className="relative w-64 h-32 mx-auto mb-8 overflow-hidden">
                                <div className="absolute inset-0 bg-gray-700 rounded-t-full opacity-50"></div>
                                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-full rounded-t-full border-[12px] border-gray-600 border-b-0"></div>
                                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-full rounded-t-full border-[12px] border-cyan-500 border-b-0 border-l-transparent border-r-transparent rotate-45"></div>
                                <div className="absolute bottom-0 left-1/2 w-1 h-24 bg-red-500 origin-bottom transform -rotate-12 transition-transform duration-1000 animate-pulse-slow"></div>
                                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-4 bg-white rounded-full"></div>
                            </div>
                            
                            <div className="text-center mb-8">
                                <div className="text-5xl font-black text-white tracking-tight">
                                    940 <span className="text-lg font-medium text-gray-400">Mbps</span>
                                </div>
                                <div className="text-xs text-cyan-400 font-mono mt-2 flex justify-center items-center">
                                    <Activity className="w-3 h-3 mr-2 animate-pulse" />
                                    CONNECTION STABLE
                                </div>
                            </div>

                            {/* Network List */}
                            <div className="space-y-3">
                                <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg border border-gray-700">
                                    <div className="flex items-center">
                                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                                        <span className="text-sm font-medium text-gray-200">Vumatel</span>
                                    </div>
                                    <Wifi className="w-4 h-4 text-gray-500" />
                                </div>
                                <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg border border-gray-700">
                                    <div className="flex items-center">
                                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                                        <span className="text-sm font-medium text-gray-200">OpenServe</span>
                                    </div>
                                    <Wifi className="w-4 h-4 text-gray-500" />
                                </div>
                                <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg border border-gray-700">
                                    <div className="flex items-center">
                                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                                        <span className="text-sm font-medium text-gray-200">MetroFibre</span>
                                    </div>
                                    <Wifi className="w-4 h-4 text-gray-500" />
                                </div>
                            </div>
                        </div>

                        {/* Floating Badge */}
                        <div className="absolute -bottom-6 -right-6 z-30 bg-brand-green text-gray-900 p-4 rounded-xl shadow-lg border border-white/20 animate-bounce-slow flex items-center gap-3">
                            <Shield className="w-6 h-6" />
                            <div>
                                <p className="text-xs font-bold uppercase opacity-80">Protection</p>
                                <p className="font-bold">Unshaped Data</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-16 items-start">
          <div>
            <div className="inline-flex items-center rounded-full px-3 py-1 text-sm font-medium text-brand-blue bg-blue-50 mb-6 border border-blue-100">
                <Zap className="w-4 h-4 mr-2" />
                Next Generation Connectivity
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6 leading-tight">
                The Backbone of Digital Life
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Fiber optic technology transmits data using light, offering speeds and stability that old copper cables simply can't match. Whether you are streaming 4K movies at home, hosting video conferences in the office, or running mission-critical cloud applications, Fiber is the answer.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              We partner with South Africa's leading Fibre Network Operators (FNOs) to bring you a wide range of options. From affordable home packages to dedicated 1:1 corporate links with guaranteed SLAs.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="flex items-start">
                    <div className="bg-green-100 p-2 rounded-lg mr-3">
                        <Zap className="w-5 h-5 text-green-700" />
                    </div>
                    <div>
                        <h4 className="font-bold text-gray-900">Symmetrical Speeds</h4>
                        <p className="text-sm text-gray-500">Upload as fast as you download.</p>
                    </div>
                </div>
                <div className="flex items-start">
                    <div className="bg-blue-100 p-2 rounded-lg mr-3">
                        <Shield className="w-5 h-5 text-brand-blue" />
                    </div>
                    <div>
                        <h4 className="font-bold text-gray-900">Uncapped Data</h4>
                        <p className="text-sm text-gray-500">No limits, no throttling.</p>
                    </div>
                </div>
            </div>
          </div>
          
          <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-100 relative">
             <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-brand-green/20 rounded-full blur-xl -z-10"></div>
             <ServiceInquiryForm serviceName="Fiber Internet Access" />
          </div>
        </div>
      </section>

      {/* Solutions Grid - Use Cases */}
      <section className="py-20 bg-gray-50" id="packages">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Select Your Solution</h2>
                <p className="text-lg text-gray-600">Tailored packages designed for different needs and budgets.</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
                {useCaseServices.map((sub) => (
                    <div key={sub.path} className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-200 hover:border-brand-blue flex flex-col">
                        <div className="mb-6 bg-blue-50 w-16 h-16 rounded-2xl flex items-center justify-center group-hover:bg-brand-blue group-hover:text-white transition-colors text-brand-blue">
                            {sub.name.includes('Home') ? <Home className="w-8 h-8" /> : 
                             sub.name.includes('Corporate') ? <Server className="w-8 h-8" /> : 
                             <Building className="w-8 h-8" />}
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-3">{sub.name}</h3>
                        <p className="text-gray-600 mb-6 flex-grow">
                            {sub.name.includes('Home') ? "High-speed entertainment and remote work connectivity for your household." :
                             sub.name.includes('Corporate') ? "Dedicated 1:1 contention ratio with guaranteed uptime SLAs for enterprise." :
                             "Professional connectivity for SMEs with prioritized support and static IPs."}
                        </p>
                        <Button onClick={() => navigate(sub.path)} variant="outline" className="w-full justify-between group-hover:bg-brand-blue group-hover:text-white group-hover:border-brand-blue">
                            View Packages <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </div>
                ))}
            </div>
        </div>
      </section>

      {/* Network Partners */}
      <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12">
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Network Partners</h2>
                  <p className="text-gray-600 max-w-2xl mx-auto">We leverage the infrastructure of South Africa's top Tier-1 providers.</p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                  {partnerServices.map((sub) => (
                      <div key={sub.path} className="flex items-center justify-between p-6 bg-gray-50 rounded-xl border border-gray-100 hover:border-gray-300 transition-colors cursor-pointer" onClick={() => navigate(sub.path)}>
                          <div className="flex items-center">
                              <div className="bg-white p-3 rounded-lg shadow-sm mr-4">
                                  <Globe className="w-6 h-6 text-gray-700" />
                              </div>
                              <div>
                                  <h4 className="font-bold text-gray-900">{sub.name}</h4>
                                  <p className="text-xs text-gray-500">Business Fibre</p>
                              </div>
                          </div>
                          <div className="text-brand-blue">
                              <ArrowRight className="w-5 h-5" />
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      </section>

       <CtaSection />
    </>
  );
};

export default FiberInternetPage;
