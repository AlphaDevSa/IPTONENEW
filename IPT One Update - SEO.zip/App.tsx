
import React, { useEffect, useCallback, useMemo } from "react";
import Header from './Header';
import Footer from './Footer';
import HomePage from './HomePage';
import ServicesPage from './ServicesPage';
import HostedPBXPage from './HostedPBXPage';
import SIPTrunksPage from './SIPTrunksPage';
import VoIPSolutionsPage from './VoIPSolutionsPage';
import LandlineNumbersPage from './LandlineNumbersPage';
import CallCenterPage from './CallCenterPage';
import NumberPortingPage from './NumberPortingPage';
import AboutPage from './AboutPage';
import ContactPage from './ContactPage';
import PrivacyPolicyPage from './PrivacyPolicyPage';
import TermsAndConditionsPage from "./TermsAndConditionsPage";
import CoverageCheckPage from "./CoverageCheckPage";
import VPBXPage from "./VPBXPage";
import VitalPBXPage from "./VitalPBXPage";
import VodiaPage from "./VodiaPage";
import UCXPage from "./UCXPage";
import YeastarPBXPage from "./YeastarPBXPage";
import IPTONEPBXPage from "./IPTONEPBXPage";
import BicomPBXPage from "./BicomPBXPage";
import ConnectivityPage from "./ConnectivityPage";
import FloatingWhatsAppButton from "./FloatingWhatsAppButton";
import FloatingSocialShare from "./FloatingSocialShare";
import WebHostingPage from "./WebHostingPage";
import DomainsPage from "./DomainsPage";
import DomainRegistrationPage from "./DomainRegistrationPage";
import DomainResellerPage from "./DomainResellerPage";
import CPanelHostingPage from "./CPanelHostingPage";
import CPanelEmailHostingPage from "./CPanelEmailHostingPage";
import DirectAdminHostingPage from "./DirectAdminHostingPage";
import WordPressHostingPage from "./WordPressHostingPage";
import ResellerHostingPage from "./ResellerHostingPage";
import LTE5GPage from "./LTE5GPage";
import MTNLTEPage from "./MTNLTEPage";
import TelkomLTEPage from "./TelkomLTEPage";
import VodacomLTEPage from "./VodacomLTEPage";
import FiberInternetPage from "./FiberInternetPage";
import NotFoundPage from "./NotFoundPage";
import FAQPage, { faqData } from "./FAQPage";
import CookieConsentBanner from "./CookieConsentBanner";
import VoIPBillingPlatformPage from "./VoIPBillingPlatformPage";
import { NavigationProvider } from './NavigationContext';
import { navStructure, NavItem } from "./servicesData";
import Breadcrumbs from "./Breadcrumbs";
import MTNFiberPage from "./MTNFiberPage";
import VodacomFiberPage from "./VodacomFiberPage";
import OpenServeFiberPage from "./OpenServeFiberPage";
import FTTHPage from "./FTTHPage";
import FTTBPage from "./FTTBPage";
import CorporateFiberPage from "./CorporateFiberPage";
import MTNFixedLTEPage from "./MTNFixedLTEPage";
import MTNMobileLTEPage from "./MTNMobileLTEPage";
import TelkomDataSimPage from "./TelkomDataSimPage";
import TelkomOnePage from "./TelkomOnePage";
import PartnersPage from "./PartnersPage";
import AgentsPage from "./AgentsPage";
import ResellersPage from "./ResellersPage";
import WholesalePage from "./WholesalePage";
import VodiaMultiTenantPage from "./VodiaMultiTenantPage";
import VitalPBXMultiTenantPage from "./VitalPBXMultiTenantPage";
import BicomMultiTenantPage from "./BicomMultiTenantPage";
import WholesaleVoiceRatesPage from "./WholesaleVoiceRatesPage";
import IPTHostedExtensionsPage from "./IPTHostedExtensionsPage";
import LandlineLandingPage from "./LandlineLandingPage";
import DataSimPage from "./DataSimPage";
import * as analytics from './analytics';
import { useLocation, useNavigate } from "react-router-dom";

const pageMetadata: { [key: string]: { title: string; description: string; keywords: string; } } = {
  '/': {
    title: 'Business VoIP, Hosted PBX & Fibre South Africa | IPT One',
    description: 'Premier Business VoIP, Cloud PBX, and Uncapped Fibre solutions for South African organizations. 99.9% uptime and enterprise-grade connectivity.',
    keywords: "VoIP South Africa, Business Fibre, Cloud PBX, Hosted PBX, SIP Trunks, LTE Data, Web Hosting, Telecoms Provider, Business Internet, 087 Numbers, ICT Solutions",
  },
  '/about': {
    title: 'About IPT One | Leading Telecoms Provider in South Africa',
    description: 'We enable business growth through reliable connectivity. Learn about IPT One\'s mission to provide world-class Voice, Fibre & Cloud infrastructure in SA.',
    keywords: "About IPT One, Telecoms Company South Africa, ICT Partner, Business Communication, VoIP Provider, Connectivity Solutions, Local Support, Telephony Experts",
  },
  '/services': {
    title: 'Business ICT Services | VoIP, Fibre & Cloud Solutions SA | IPT One',
    description: "Explore our comprehensive technology solutions. From crystal-clear VoIP and high-speed Fibre to scalable Cloud Hosting for modern businesses in South Africa.",
    keywords: "ICT Services, Business Communication, VoIP Services, Internet Connectivity, Cloud Solutions, Managed Services, Telecoms Solutions, Business Fibre",
  },
  '/services/hosted-pbx': {
    title: 'Cloud Hosted PBX Systems for SA Businesses | IPT One',
    description: 'Scalable Cloud PBX solutions. Feature-rich VoIP phone systems designed for remote and hybrid teams in South Africa.',
    keywords: "Hosted PBX, Cloud Phone System, Virtual PBX, Business VoIP, Remote Work Phone, Unified Communications, Cloud Voice, Office Phone System, VoIP South Africa",
  },
  '/services/hosted-pbx/vpbx': {
    title: 'vPBX Cloud Phone System | Affordable VoIP for Small Business | IPT One',
    description: 'vPBX: The best value cloud phone system for startups and SMEs in SA. Get enterprise voice features at a fraction of the cost. Sign up online.',
    keywords: "vPBX, Small Business VoIP, Affordable PBX, Startup Phone System, Cloud Voice, Easy VoIP, Hosted PBX, SME Communication, Cheap VoIP SA",
  },
  '/services/hosted-pbx/vitalpbx': {
    title: 'VitalPBX Unified Communications | Voice, Video & Chat | IPT One',
    description: 'Unified Communications made simple. VitalPBX integrates voice, video conferencing, chat, and file sharing into one powerful platform for modern teams.',
    keywords: "VitalPBX, Unified Communications, Video Conferencing, Business Chat, Collaboration Platform, UCaaS, VitalPBX South Africa, Omni-channel",
  },
  '/services/hosted-pbx/vodia': {
    title: 'Vodia PBX for MSPs | Multi-Tenant Cloud VoIP Solution | IPT One',
    description: 'Vodia PBX: The preferred multi-tenant VoIP solution for MSPs and Resellers. Robust, white-label ready, and seamless Microsoft Teams integration.',
    keywords: "Vodia PBX, Multi-Tenant PBX, MSP VoIP, Reseller PBX, Microsoft Teams Integration, White Label PBX, Teams Direct Routing, Vodia SA",
  },
  '/services/hosted-pbx/ucx': {
    title: 'UCX Hosted PBX | Unified Customer Experience | IPT One',
    description: 'UCX PBX: A powerful, all-in-one cloud communication platform designed for modern business interaction. Unified voice, video, and messaging.',
    keywords: "UCX PBX, Unified Communications, Customer Experience, Cloud PBX, Business VoIP, UCaaS, Hosted PBX",
  },
  '/services/hosted-pbx/yeastar': {
    title: 'Yeastar Hosted PBX | P-Series Cloud Edition | IPT One',
    description: 'Yeastar P-Series Cloud Edition. A converged system for voice, video, applications, and collaboration. Linkus UC clients included.',
    keywords: "Yeastar PBX, P-Series Cloud, Linkus, Cloud PBX, Business VoIP, Yeastar South Africa, Unified Communications",
  },
  '/services/hosted-pbx/iptone-pbx': {
    title: 'IPT One Managed PBX | White-Glove Business Voice Solution | IPT One',
    description: 'Experience total peace of mind with our fully managed IPT One PBX. We handle configuration, monitoring, and support so you can focus on your business.',
    keywords: "Managed PBX, Managed VoIP, Enterprise Phone System, Custom PBX, Dedicated Support, Business Telephony, High Availability VoIP, Managed Voice Services",
  },
  '/services/hosted-pbx/bicom-pbx': {
    title: 'Bicom Systems PBXware | Professional Call Center & UC | IPT One',
    description: 'Bicom Systems PBXware: The gold standard for stability and features. Ideal for call centers, large enterprises, and government institutions in SA.',
    keywords: "Bicom Systems, PBXware, Enterprise UC, Call Center PBX, Professional VoIP, Bicom South Africa, GloCOM, Unified Comms",
  },
  '/services/hosted-pbx/ipt-hosted-extensions': {
    title: 'Hosted PBX Extensions | Scalable Per-User Voice Packages | IPT One',
    description: 'Flexible VoIP extension packages tailored to your team size. Pay per user with included features and competitive call rates. Instant setup.',
    keywords: "Hosted Extensions, Cloud Voice Packages, Scalable PBX, Business VoIP Extensions, Per User VoIP, Cloud Telephony Packages, VoIP Seats",
  },
  '/services/sip-trunks': {
    title: 'Business SIP Trunks | Wholesale VoIP Termination SA | IPT One',
    description: 'Connect your on-premise PBX to our carrier-grade network. Save up to 50% on calls with superior voice quality, reliability and redundancy.',
    keywords: "SIP Trunks, Business SIP, VoIP Trunking, IP Telephony, PBX Connectivity, Voice Over IP, Wholesale VoIP, Call Termination, SIP Provider SA",
  },
  '/services/voip-solutions': {
    title: 'Business VoIP Solutions | Modern Unified Communications | IPT One',
    description: 'Future-proof your business with advanced VoIP. Crystal-clear HD voice, seamless mobility, and unified tools for the modern hybrid workforce.',
    keywords: "Business VoIP, Enterprise Voice, Unified Communications, VoIP Solutions, Internet Calling, HD Voice, Corporate Telephony, Digital Voice",
  },
  '/services/landline-numbers': {
    title: '087 & Geographic Business Numbers | Virtual Landlines SA | IPT One',
    description: 'Get a professional business number (011, 021, 087) instantly. Answer calls on your mobile or laptop anywhere in South Africa.',
    keywords: "Virtual Landline, Business Number, 087 Number, 011 Number, 021 Number, VoIP Number, Digital Landline, Geographic Numbers, SA Phone Number",
  },
  '/landline-deal': {
    title: 'Get a Business Landline on Your Mobile | R49pm | IPT One',
    description: 'Limited Offer: Get a 011, 021 or 087 landline number on your mobile phone. No contracts. Instant setup. Sign up now.',
    keywords: "Landline on Mobile, Business Number Special, Cheap Landline, 087 Number Deal, VoIP Special",
  },
  '/services/number-porting': {
    title: 'Number Porting Services | Keep Your Business Number | IPT One',
    description: 'Switching to IPT One is easy. We handle the full Number Porting (GNP) process so you keep your existing business telephone numbers.',
    keywords: "Number Porting, Port Phone Number, GNP, LNP, Keep My Number, Switch Telecoms, Number Migration, Business Number Porting, Porting SA",
  },
  '/services/call-center-solutions': {
    title: 'Cloud Call Center Software | Omnichannel Contact Center | IPT One',
    description: 'Empower your agents with our Cloud Contact Center software. Features include predictive dialers, skills-based routing, and real-time analytics.',
    keywords: "Call Center Software, Contact Center Solution, Omnichannel Support, Predictive Dialer, Call Center Analytics, Cloud Contact Center, Call Center VoIP",
  },
  '/web-hosting': {
    title: 'Secure Web Hosting & Domain Registration South Africa | IPT One',
    description: 'Fast, secure Linux hosting and local .co.za domain registration. Powered by high-performance cloud infrastructure.',
    keywords: "Web Hosting South Africa, cPanel Hosting, WordPress Hosting, Secure Hosting, Business Email, Domain Registration, Website Hosting, SA Hosting",
  },
  '/web-hosting/domains': {
    title: 'Domain Registration South Africa | Buy .co.za & .com Domains | IPT One',
    description: 'Secure your online identity. Search and register .co.za, .com, and other top-level domains instantly with free DNS management.',
    keywords: "Domain Registration, Buy Domain, .co.za Domain, Web Address, Domain Name Search, Internet Domains, DNS Management, Register Domain SA",
  },
  '/web-hosting/domains/domain-registration': {
    title: 'Instant Domain Registration | Check Availability & Register | IPT One',
    description: 'Find your perfect website name. Quick, easy, and affordable domain registration for South African businesses. Get online today.',
    keywords: "Register Domain, Cheap Domains, Domain Name Check, Website Name, URL Registration, Domain Registration, .co.za Domain, Domain Search",
  },
  '/web-hosting/domains/domain-reseller': {
    title: 'Domain Reseller Program | White Label Domain Registration | IPT One',
    description: 'Start your own registrar business. Access wholesale domain pricing, white-label API, and WHMCS modules to sell domains under your brand.',
    keywords: "Domain Reseller, Sell Domains, White Label Domains, Domain API, Reseller Program, Web Hosting Reseller, Domain Business, ZACR Reseller",
  },
  '/web-hosting/cpanel-hosting': {
    title: 'cPanel Web Hosting | Reliable & Easy Website Management | IPT One',
    description: 'The world\'s #1 control panel. Manage your website files, email accounts, and databases easily with our high-speed cPanel Hosting.',
    keywords: "cPanel Hosting, Linux Hosting, PHP Hosting, MySQL Hosting, Easy Web Hosting, Secure Hosting, Website Management, Affordable Hosting",
  },
  '/web-hosting/cpanel-email-hosting': {
    title: 'Professional Business Email | Secure cPanel Email Hosting | IPT One',
    description: 'Look professional with email at your domain (you@yourcompany.co.za). Secure, spam-free cPanel email hosting with webmail access.',
    keywords: "Business Email, Email Hosting, Professional Email, Custom Email Address, Secure Email, Webmail, cPanel Email, Corporate Email",
  },
  '/web-hosting/directadmin-hosting': {
    title: 'DirectAdmin Web Hosting | Fast, Lightweight & Efficient | IPT One',
    description: 'Blazing fast DirectAdmin hosting. A lightweight, resource-efficient control panel perfect for developers and performance-focused sites.',
    keywords: "DirectAdmin Hosting, Fast Web Hosting, Lightweight Hosting, DirectAdmin Panel, Efficient Hosting, VPS Hosting Alternative, Developer Hosting",
  },
  '/web-hosting/wordpress-hosting': {
    title: 'Managed WordPress Hosting | Optimized for Speed & Security | IPT One',
    description: 'Get the best out of WordPress. Managed hosting with auto-updates, advanced caching, and enhanced security for blazing fast websites.',
    keywords: "WordPress Hosting, Managed WordPress, WP Hosting, Fast WordPress, Secure WordPress, WordPress Optimization, LiteSpeed WordPress",
  },
  '/web-hosting/reseller-hosting': {
    title: 'Reseller Web Hosting | Launch Your Own Hosting Business | IPT One',
    description: 'Become a web hosting provider with our white-label Reseller Hosting. Create plans, set prices, and manage clients via WHM.',
    keywords: "Reseller Hosting, White Label Hosting, Web Hosting Business, WHM Reseller, Hosting Provider, Start Hosting Business, Reseller Packages",
  },
  '/connectivity': {
    title: 'Business Fibre & LTE Connectivity | High-Speed Internet SA',
    description: 'Uncapped Business Fibre and 5G/LTE solutions. Check coverage for OpenServe, Vumatel, and MetroFibre instantly.',
    keywords: "Business Connectivity, Business Internet, Fibre Internet, LTE, 5G, Internet Solutions, Wireless Internet, Broadband Solutions, SA Internet, business internet solutions, fibre speeds, LTE data plans",
  },
  '/connectivity/lte-5g': {
    title: 'Business LTE & 5G | Fast Mobile Broadband Solutions | IPT One',
    description: 'Instant connectivity with Business LTE & 5G. Ideal primary connection for agile businesses or as a robust failover for 100% uptime.',
    keywords: "Business LTE, 5G Internet, Wireless Broadband, Mobile Data, Backup Internet, Remote Connectivity, LTE Data, 5G Router",
  },
  '/connectivity/lte-5g/mtn': {
    title: 'MTN Business LTE & 5G | Reliable Mobile Data Plans | IPT One',
    description: 'Harness the power of MTN\'s award-winning network. Flexible fixed and mobile data packages designed for business reliability and speed.',
    keywords: "MTN LTE, MTN 5G, MTN Data Deals, MTN Business Data, Business LTE, Wireless Internet, High Speed Mobile Data, MTN Deals",
  },
  '/connectivity/lte-5g/mtn-fixed': {
    title: 'MTN Fixed LTE & 5G | High-Speed Home & Office Internet | IPT One',
    description: 'Stable, high-speed MTN Fixed LTE & 5G. Fibre-like speeds for your home or office without the need for cables or installation delays.',
    keywords: "Fixed LTE, Fixed 5G, Home Internet, Office Internet, MTN Fixed Data, Wireless Fibre, Router Deals, MTN Fixed LTE",
  },
  '/connectivity/lte-5g/mtn-mobile': {
    title: 'MTN Mobile Data SIMs | Internet on the Go | IPT One',
    description: 'Stay connected anywhere with MTN Mobile Data. Flexible SIM-only plans for routers, tablets, and smartphones. No location locking.',
    keywords: "Mobile Data, Data SIM, MTN Mobile, Portable Internet, Travel Internet, SIM Only Data, Flexible Data Plans, Anywhere Data",
  },
  '/connectivity/lte-5g/telkom': {
    title: 'Telkom LTE & 5G Deals | Affordable Wireless Internet | IPT One',
    description: 'Maximize value with Telkom LTE & 5G. Affordable, high-volume data packages perfect for cost-effective business and home connectivity.',
    keywords: "Telkom LTE, Telkom 5G, Affordable Internet, Telkom Data Deals, Wireless Broadband, Business LTE, Value Data Deals, Telkom WiFi",
  },
  '/connectivity/lte-5g/telkom-data-sim': {
    title: 'Telkom Data SIM Cards | 4G/5G Mobile Data Plans | IPT One',
    description: 'Cost-effective Telkom Data SIMs. Reliable 4G/5G connectivity for teams, routers, and IoT devices at unbeatable rates.',
    keywords: "Telkom Data SIM, Mobile Data Plans, IoT Data, Business SIM Cards, Telkom LTE, Mobile WiFi, Cheap Data SIM",
  },
  '/connectivity/lte-5g/telkom-one': {
    title: 'Telkom One | All-In-One Voice & Data Mobile Plan | IPT One',
    description: 'Telkom One: The ultimate business mobile plan. Bundled voice minutes, data, and SMS in a single, affordable package.',
    keywords: "Telkom One, All-in-One Mobile Plan, Voice and Data Bundle, Business Mobile Plan, Telkom LTE, Mobile Landline, Integrated Mobile",
  },
  '/connectivity/lte-5g/vodacom': {
    title: 'Vodacom Business LTE & 5G | Premium Enterprise Connectivity | IPT One',
    description: 'Connect with confidence on Vodacom\'s reliable network. Business LTE & 5G ensuring superior coverage for mission-critical operations.',
    keywords: "Vodacom LTE, Vodacom 5G, Enterprise Connectivity, Business Internet, Reliable Mobile Data, Mission Critical Internet, Vodacom Business",
  },
  '/connectivity/fiber-internet': {
    title: 'Business Fibre Internet | Uncapped & Symmetrical Speeds | IPT One',
    description: 'Upgrade to reliable Business Fibre. Symmetrical speeds, low latency, and 99% uptime guarantees for critical business operations.',
    keywords: "Business Fibre, Uncapped Fibre, Symmetrical Internet, Dedicated Fibre, Fibre Internet, Business Connectivity, Fibre Optic, FTTB",
  },
  '/connectivity/fiber-internet/mtn': {
    title: 'MTN Business Fibre | Reliable High-Speed Office Internet | IPT One',
    description: 'Power your office with MTN Business Fibre. Robust, high-speed connectivity backed by a trusted national network infrastructure.',
    keywords: "MTN Fibre, MTN Business Internet, Fibre Connectivity, Reliable Fibre, Business Fibre, Uncapped Fibre, MTN Business",
  },
  '/connectivity/fiber-internet/vodacom': {
    title: 'Vodacom Business Fibre | Premium Enterprise Internet | IPT One',
    description: 'Vodacom Business Fibre: Premium enterprise connectivity with guaranteed uptime SLAs. The choice for businesses that can\'t afford downtime.',
    keywords: "Vodacom Fibre, Enterprise Fibre, Premium Internet, Business Connectivity Solutions, Business Fibre, Uncapped Fibre, Vodacom Business",
  },
  '/connectivity/fiber-internet/openserve': {
    title: 'OpenServe Premium Fibre | Uncapped Home & Business Internet | IPT One',
    description: 'Get connected with OpenServe Fibre. Premium, uncapped, and unshaped internet with a 14-day speed boost. Free router & installation included.',
    keywords: "OpenServe Fibre, Home Fibre, Uncapped Fibre, Premium Internet, OpenServe Deals, Fibre Installation, High Speed Internet",
  },
  '/connectivity/fiber-internet/ftth': {
    title: 'Fibre To The Home (FTTH) | Fast Uncapped Home Internet | IPT One',
    description: 'Transform home connectivity with Fibre to the Home (FTTH). Blazing fast, uncapped internet for streaming, gaming, and remote work.',
    keywords: "FTTH, Fibre to the Home, Home Internet, Fast Home WiFi, Uncapped Home Fibre, Fibre Internet, Vumatel, Openserve",
  },
  '/connectivity/fiber-internet/fttb': {
    title: 'Fibre To The Business (FTTB) | Professional Office Internet | IPT One',
    description: 'Dedicated Fibre To The Business (FTTB). Stable, high-bandwidth connection for efficiency, VoIP, and cloud applications.',
    keywords: "FTTB, Fibre to the Business, Office Internet, Business Broadband, Commercial Fibre, Business Fibre, Small Business Fibre",
  },
  '/connectivity/fiber-internet/corporate': {
    title: 'Corporate Fibre Internet | Dedicated 1:1 Enterprise Links | IPT One',
    description: 'Premium Corporate Fibre with 1:1 contention. Guaranteed bandwidth and SLAs for enterprises requiring mission-critical uptime.',
    keywords: "Corporate Fibre, Dedicated Fibre, 1:1 Contention, Enterprise Internet, SLA Internet, Managed Internet, Leased Line",
  },
  '/connectivity/data-sim': {
    title: 'Data SIM Deals | Flexible Mobile Broadband for Home & Business | IPT One',
    description: 'Mobile Data SIMs on MTN, Telkom and Vodacom. High-speed LTE and 5G data for routers, tablets and mobile teams with flexible caps and uncapped options.',
    keywords: "Data SIM, Mobile Data SIM, LTE Data, 5G Data, MTN Data SIM, Telkom Data SIM, Vodacom Data SIM, Business Data SIM, Router SIM, Mobile Broadband",
  },
  '/connectivity/data-sim/mtn': {
    title: 'MTN Data SIM Deals | LTE & 5G Mobile Broadband | IPT One',
    description: 'MTN-powered Data SIM packages for routers and mobile devices. Fast, reliable LTE and 5G connectivity on South Africa’s top-performing mobile network.',
    keywords: "MTN Data SIM, MTN LTE Data, MTN 5G Data, Mobile Broadband, Data SIM Deals, Business Data SIM, MTN Router SIM, Portable Internet",
  },
  '/partners': {
    title: 'Telecoms Partner Programs | Reseller, Agent & Wholesale | IPT One',
    description: 'Partner with IPT One to grow revenue. Join our Agent referral program, become a White-Label Reseller, or access Wholesale carrier rates.',
    keywords: "Telecoms Partner, Reseller Program, Agent Program, Wholesale Telecoms, Business Partnership, White Label Telecoms, Wholesale VoIP, ICT Partner",
  },
  '/partners/agents': {
    title: 'Telecoms Agent Program | Earn Recurring Commissions | IPT One',
    description: 'Become an IPT One Agent and build passive income. Refer clients for VoIP, Fibre, and Hosting to earn recurring monthly commissions.',
    keywords: "Telecoms Agent, Referral Program, Commission Based, Sales Agent, Partner Program, Affiliate Program, Earn Passive Income",
  },
  '/partners/resellers': {
    title: 'White Label Telecoms Reseller | Start Your Own VoIP Business | IPT One',
    description: 'Launch your own VoIP brand with our turnkey Reseller Program. We provide platform, billing, and support; you own the customer relationship.',
    keywords: "VoIP Reseller, White Label Telecoms, Reseller Business, Telecoms Franchise, Start VoIP Business, White Label Solution, MSP Program",
  },
  '/partners/wholesale': {
    title: 'Wholesale VoIP & Connectivity | Carrier Services SA | IPT One',
    description: 'Carrier-grade wholesale Voice & Data for ISPs. Access premium voice termination, white-label platforms, and bulk data at wholesale rates.',
    keywords: "Wholesale VoIP, Carrier Services, Wholesale Data, Voice Termination, ISP Services, Wholesale Call Minutes, Voice Servers, Telecoms Wholesale",
  },
  '/partners/wholesale/billing-platform': {
    title: 'VoIP Billing Platform & Softswitch | Wholesale VoIP Management | IPT One',
    description: 'Advanced VoIP Billing Platform and Softswitch. Real-time rating, multi-tenant management, and automated billing for service providers.',
    keywords: "VoIP Billing, Softswitch, Telecom Billing Software, Wholesale VoIP Platform, VoIP Management, Billing System, PortaOne, Class 5 Switch",
  },
  '/partners/wholesale/voice-rates': {
    title: 'Wholesale Voice Rates | Bulk VoIP Termination South Africa | IPT One',
    description: 'Maximize margins with competitive Wholesale Voice Rates. Premium CLI routes, high ASR, and volume-based discounts for carriers.',
    keywords: "Wholesale Voice Rates, VoIP Termination, Bulk Voice, CLI Routes, Call Center Rates, Wholesale Call Minutes, ASR, Voice Termination",
  },
  '/partners/wholesale/vodia-multi-tenant': {
    title: 'Vodia Multi-Tenant PBX | Wholesale Cloud Voice Platform | IPT One',
    description: 'Vodia Multi-Tenant PBX for Service Providers. Scalable, cloud-native platform to offer robust hosted PBX services under your brand.',
    keywords: "Vodia Multi-Tenant, Wholesale PBX, Cloud Voice Platform, MSP PBX, Service Provider VoIP, Vodia PBX, White Label Hosted PBX",
  },
  '/partners/wholesale/vitalpbx-multi-tenant': {
    title: 'VitalPBX Carrier Edition | Wholesale Multi-Tenant Switch | IPT One',
    description: 'VitalPBX Multi-Tenant Carrier Edition. Powerful softswitch with integrated billing and routing for wholesale VoIP providers and carriers.',
    keywords: "VitalPBX Multi-Tenant, Carrier PBX, Wholesale UC, Multi-Tenant Switch, VoIP Carrier, VitalPBX, Sonata Switch, Unified Communications",
  },
  '/partners/wholesale/bicom-multi-tenant': {
    title: 'Bicom PBXware Multi-Tenant | White Label UC Platform | IPT One',
    description: 'Bicom PBXware Multi-Tenant: The industry standard for hosted VoIP. Complete white-label UC solution for Telecoms Service Providers.',
    keywords: "Bicom Multi-Tenant, PBXware, White Label UC, ITSP Platform, Hosted VoIP Platform, Bicom Systems, Softswitch, GloCOM Branding",
  },
  '/coverage-check': {
    title: 'Fibre & LTE Coverage Map | Check Internet Availability SA | IPT One',
    description: 'Check Fibre & LTE coverage in your area instantly. Compare availability from major providers and find the best internet for your location.',
    keywords: "Fibre Coverage, LTE Coverage, 5G Availability, Internet Check, Connectivity Map, Coverage Map South Africa, Check Fibre, Vumatel Coverage",
  },
  '/contact': {
    title: 'Contact IPT One | Sales & Support for Business Telecoms',
    description: 'Contact IPT One for sales & support. Get custom quotes, technical help, or expert advice on VoIP & connectivity solutions 24/7.',
    keywords: "Contact IPT One, Telecoms Support, Sales Inquiry, Customer Service, Tech Support, VoIP Help, Fibre Support, Contact Us",
  },
  '/faq': {
    title: 'Telecoms FAQ | Support for VoIP, Fibre & Hosting | IPT One',
    description: 'IPT One FAQ: Answers to common questions about VoIP quality, Number Porting, Fibre installation, and Web Hosting. Expert advice.',
    keywords: "Telecoms FAQ, VoIP Questions, Internet Help, Hosting Support, Frequently Asked Questions, Knowledge Base, Support Center",
  },
  '/privacy-policy': {
    title: 'Privacy Policy | Data Protection & POPIA Compliance | IPT One',
    description: 'Read our Privacy Policy. We are committed to protecting your personal information and ensuring POPIA compliance.',
    keywords: "Privacy Policy, POPIA, Data Protection, Personal Information, Terms of Service, GDPR Compliance, Legal",
  },
  '/terms-and-conditions': {
    title: 'General Terms and Conditions | Service Agreement | IPT One',
    description: 'Review IPT One\'s Terms & Conditions. Understand your rights and obligations regarding the use of our services.',
    keywords: "Terms and Conditions, Service Agreement, Legal Terms, Customer Rights, Telecoms Contract, Acceptable Use Policy, SLA",
  },
  '404': {
    title: '404 - Page Not Found | IPT One Telecoms',
    description: '404 - Page Not Found. Return to IPT One to explore reliable Business VoIP, Hosted PBX & Connectivity solutions.',
    keywords: "404 Error, Page Not Found, Broken Link, IPT One Telecoms, Error Page",
  },
};

const routeComponents: { [key: string]: React.FC } = {
  '/': HomePage,
  '/services': ServicesPage,
  '/services/hosted-pbx': HostedPBXPage,
  '/services/sip-trunks': SIPTrunksPage,
  '/services/voip-solutions': VoIPSolutionsPage,
  '/services/landline-numbers': LandlineNumbersPage,
  '/landline-deal': LandlineLandingPage,
  '/services/number-porting': NumberPortingPage,
  '/partners/wholesale/billing-platform': VoIPBillingPlatformPage,
  '/partners/wholesale/voice-rates': WholesaleVoiceRatesPage,
  '/partners/wholesale/vodia-multi-tenant': VodiaMultiTenantPage,
  '/partners/wholesale/vitalpbx-multi-tenant': VitalPBXMultiTenantPage,
  '/partners/wholesale/bicom-multi-tenant': BicomMultiTenantPage,
  '/services/call-center-solutions': CallCenterPage,
  '/about': AboutPage,
  '/connectivity': ConnectivityPage,
  '/contact': ContactPage,
  '/privacy-policy': PrivacyPolicyPage,
  '/terms-and-conditions': TermsAndConditionsPage,
  '/coverage-check': CoverageCheckPage,
  '/services/hosted-pbx/vpbx': VPBXPage,
  '/services/hosted-pbx/vitalpbx': VitalPBXPage,
  '/services/hosted-pbx/vodia': VodiaPage,
  '/services/hosted-pbx/ucx': UCXPage,
  '/services/hosted-pbx/yeastar': YeastarPBXPage,
  '/services/hosted-pbx/iptone-pbx': IPTONEPBXPage,
  '/services/hosted-pbx/bicom-pbx': BicomPBXPage,
  '/services/hosted-pbx/ipt-hosted-extensions': IPTHostedExtensionsPage,
  '/web-hosting': WebHostingPage,
  '/web-hosting/domains': DomainsPage,
  '/web-hosting/domains/domain-registration': DomainRegistrationPage,
  '/web-hosting/domains/domain-reseller': DomainResellerPage,
  '/web-hosting/cpanel-hosting': CPanelHostingPage,
  '/web-hosting/cpanel-email-hosting': CPanelEmailHostingPage,
  '/web-hosting/directadmin-hosting': DirectAdminHostingPage,
  '/web-hosting/wordpress-hosting': WordPressHostingPage,
  '/web-hosting/reseller-hosting': ResellerHostingPage,
  '/connectivity/lte-5g': LTE5GPage,
  '/connectivity/lte-5g/mtn': MTNLTEPage,
  '/connectivity/lte-5g/mtn-fixed': MTNFixedLTEPage,
  '/connectivity/lte-5g/mtn-mobile': MTNMobileLTEPage,
  '/connectivity/lte-5g/telkom': TelkomLTEPage,
  '/connectivity/lte-5g/telkom-data-sim': TelkomDataSimPage,
  '/connectivity/lte-5g/telkom-one': TelkomOnePage,
  '/connectivity/lte-5g/vodacom': VodacomLTEPage,
  '/connectivity/fiber-internet': FiberInternetPage,
  '/connectivity/fiber-internet/mtn': MTNFiberPage,
  '/connectivity/fiber-internet/vodacom': VodacomFiberPage,
  '/connectivity/fiber-internet/openserve': OpenServeFiberPage,
  '/connectivity/fiber-internet/ftth': FTTHPage,
  '/connectivity/fiber-internet/fttb': FTTBPage,
  '/connectivity/fiber-internet/corporate': CorporateFiberPage,
  '/connectivity/data-sim': DataSimPage,
  '/connectivity/data-sim/mtn': DataSimPage,
  '/faq': FAQPage,
  '/partners': PartnersPage,
  '/partners/agents': AgentsPage,
  '/partners/resellers': ResellersPage,
  '/partners/wholesale': WholesalePage,
};

const updateSeoTags = (metadata: { title: string; description: string; keywords: string; }, path: string) => {
    document.title = metadata.title;
    const origin = 'https://iptone.co.za';
    const normalizedPath = path.startsWith('/') ? path : `/${path}`;
    const fullUrl = origin + normalizedPath;

    const setAttr = (selector: string, attr: string, value: string) => {
        const element = document.querySelector(selector);
        if (element) element.setAttribute(attr, value);
    };

    setAttr('meta[name="description"]', 'content', metadata.description);
    setAttr('meta[name="keywords"]', 'content', metadata.keywords);
    setAttr('#canonical-link', 'href', fullUrl);
    setAttr('#og-title', 'content', metadata.title);
    setAttr('#og-description', 'content', metadata.description);
    setAttr('#og-url', 'content', fullUrl);
    setAttr('#twitter-title', 'content', metadata.title);
    setAttr('#twitter-description', 'content', metadata.description);
    setAttr('#twitter-url', 'content', fullUrl);
    
    let robotsTag = document.querySelector('meta[name="robots"]');
    if (!robotsTag) {
        robotsTag = document.createElement('meta');
        robotsTag.setAttribute('name', 'robots');
        document.head.appendChild(robotsTag);
    }
    robotsTag.setAttribute('content', 'index, follow');
};

const updateStructuredData = (path: string, trail: { name: string; path: string }[]) => {
    const scriptId = 'page-specific-schema';
    document.getElementById(scriptId)?.remove();
    
    const metadata = pageMetadata[path] || pageMetadata['/'];
    if (!metadata) return;

    const origin = 'https://iptone.co.za';
    const normalizedPath = path.startsWith('/') ? path : `/${path}`;
    const fullUrl = origin + normalizedPath;
    const schemas = [];

    if (trail && trail.length > 0) {
        schemas.push({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": trail.map((crumb, index) => ({
                "@type": "ListItem",
                "position": index + 1,
                "name": crumb.name,
                "item": origin + crumb.path
            }))
        });
    }

    if (path === '/faq') {
        schemas.push({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqData.flatMap(category => 
                category.questions.map(item => ({
                    "@type": "Question",
                    "name": item.q,
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": item.a
                    }
                }))
            )
        });
    } else if (path.startsWith('/services/') || path.startsWith('/web-hosting/') || path.startsWith('/connectivity/') || path.startsWith('/partners/')) {
        schemas.push({
            "@context": "https://schema.org",
            "@type": "Service",
            "name": metadata.title.split('|')[0].trim(),
            "description": metadata.description,
            "url": fullUrl,
            "provider": { "@type": "Organization", "name": "IPT One Telecoms", "url": "https://iptone.co.za" },
            "areaServed": { "@type": "Country", "name": "ZA" },
        });
    } else {
        schemas.push({
            "@context": "https://schema.org",
            "@type": "WebPage",
            "url": fullUrl,
            "name": metadata.title,
            "description": metadata.description,
            "isPartOf": { "@type": "WebSite", "url": "https://iptone.co.za" }
        });
    }
    
    if(schemas.length > 0) {
      const script = document.createElement('script');
      script.id = scriptId;
      script.type = 'application/ld+json';
      script.textContent = JSON.stringify({
          "@context": "https://schema.org",
          "@graph": schemas
      });
      document.head.appendChild(script);
    }
}

export default function App() {
  const location = useLocation();
  const routerNavigate = useNavigate();
  const currentPath = location.pathname || '/';

  const pathMap = useMemo(() => {
      const map = new Map<string, string>();
      const traverse = (items: NavItem[], basePath = '', baseName = '') => {
          items.forEach(item => {
              map.set(item.path, item.name);
              if (item.subServices) traverse(item.subServices, item.path, item.name);
          });
      };
      traverse(navStructure);
      map.set('/about', 'About');
      map.set('/contact', 'Contact');
      map.set('/privacy-policy', 'Privacy Policy');
      map.set('/terms-and-conditions', 'Terms and Conditions');
      map.set('/coverage-check', 'Coverage Check');
      map.set('/faq', 'FAQ');
      return map;
  }, []);

  const generateBreadcrumbTrail = useCallback((path: string) => {
      if (path === '/') return [];
      const homeCrumb = { name: 'Home', path: '/' };
      const trail = [homeCrumb];
      const segments = path.split('/').filter(Boolean);
      let currentPath = '';

      for (const segment of segments) {
          currentPath += `/${segment}`;
          const name = pathMap.get(currentPath);
          if (name) {
              trail.push({ name, path: currentPath });
          }
      }
      return trail;
  }, [pathMap]);

  const navigate = useCallback((path: string) => {
    routerNavigate(path);
    window.scrollTo(0, 0);
  }, [routerNavigate]);

  useEffect(() => {
    const isNotFound = !routeComponents[currentPath];
    const metadataKey = isNotFound ? '404' : currentPath;
    const metadata = pageMetadata[metadataKey] || pageMetadata['/'];
    const breadcrumbTrail = generateBreadcrumbTrail(currentPath);
    
    updateSeoTags(metadata, currentPath);
    updateStructuredData(currentPath, breadcrumbTrail);
    analytics.pageview(currentPath);

    return () => {
      document.getElementById('page-specific-schema')?.remove();
    }
  }, [currentPath, generateBreadcrumbTrail]);

  const PageComponent = routeComponents[currentPath] || NotFoundPage;
  const breadcrumbTrail = generateBreadcrumbTrail(currentPath);
  const isLandingPage = currentPath === '/landline-deal';

  return (
    <NavigationProvider value={navigate}>
      <div className={`bg-gray-50 min-h-screen font-sans text-gray-800 ${isLandingPage ? '' : 'pt-20'}`}>
          {!isLandingPage && <Header currentPath={currentPath} />}
          <main>
              {currentPath !== '/' && !isLandingPage && breadcrumbTrail.length > 0 && (
                <div className="bg-white border-b border-gray-200">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <Breadcrumbs trail={breadcrumbTrail} />
                    </div>
                </div>
              )}
              <PageComponent key={currentPath} />
          </main>
          {!isLandingPage && <Footer />}
          <FloatingWhatsAppButton />
          <FloatingSocialShare />
          <CookieConsentBanner />
      </div>
    </NavigationProvider>
  );
}
