
import React from 'react';
import { Cloud, Server, Wifi, Globe, Building, Users, Database, Tower, SimCard, Phone, CheckCircle, Zap } from "./components/icons";

export interface NavItem {
    name: string;
    path: string;
    isCategory?: boolean;
    icon?: React.ReactNode;
    description?: string;
    content?: string;
    image?: string;
    subServices?: NavItem[];
}

export const navStructure: NavItem[] = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    {
        name: 'Services',
        path: '/services',
        isCategory: true,
        icon: React.createElement(Cloud, { className: "w-8 h-8 text-brand-blue" }),
        description: "VoIP, SIP Trunks & more.",
        content: "A complete suite of telecommunication services to connect your team and customers.",
        subServices: [
            { 
                name: "SIP Trunks", 
                path: "/services/sip-trunks",
                icon: React.createElement(Server, { className: "w-6 h-6 text-brand-blue" }),
                description: "Connect your existing PBX to our powerful voice network.",
            },
            { 
                name: "VoIP Solutions", 
                path: "/services/voip-solutions",
                icon: React.createElement(Phone, { className: "w-6 h-6 text-brand-blue" }),
                description: "Harness the power of the internet for business communications.",
            },
            { 
                name: "Landline Numbers", 
                path: "/services/landline-numbers",
                icon: React.createElement(Globe, { className: "w-6 h-6 text-brand-blue" }),
                description: "Establish a professional, local presence anywhere in South Africa.",
            },
            {
                name: "Number Porting",
                path: "/services/number-porting",
                icon: React.createElement(Phone, { className: "w-6 h-6 text-brand-blue" }),
                description: "Keep your existing numbers when you switch to us.",
            },
            { 
                name: "Call Center Solutions", 
                path: "/services/call-center-solutions",
                icon: React.createElement(Building, { className: "w-6 h-6 text-brand-blue" }),
                description: "Empower your teams with our feature-rich call center platform.",
            },
        ]
    },
    {
        name: "Hosted PBX",
        path: "/services/hosted-pbx",
        isCategory: true,
        icon: React.createElement(Cloud, { className: "w-8 h-8 text-brand-blue" }),
        description: "Powerful, flexible, and scalable cloud-based phone systems.",
        content: "Choose the platform that best fits your business needs.",
        subServices: [
            { name: "vPBX", path: "/services/hosted-pbx/vpbx", image: "/images/vpbx.png" },
            { name: "VitalPBX", path: "/services/hosted-pbx/vitalpbx", image: "/images/vitalpbx.png" },
            { name: "Vodia", path: "/services/hosted-pbx/vodia", image: "/images/vodia.png" },
            { name: "UCX Hosted PBX", path: "/services/hosted-pbx/ucx", image: "/images/ucxlogo.png" },
            { name: "Yeastar Hosted PBX", path: "/services/hosted-pbx/yeastar", image: "/images/yeastar.png" },
            { name: "IPT One PBX", path: "/services/hosted-pbx/iptone-pbx", image: "/images/ipthostedpbx.png" },
            { name: "Bicom PBX", path: "/services/hosted-pbx/bicom-pbx", image: "/images/bicom.png" },
            { name: "IPT Hosted Extensions", path: "/services/hosted-pbx/ipt-hosted-extensions", image: "/images/ipthostedextensions.png" },
        ]
    },
    {
        name: 'Domains',
        path: '/web-hosting/domains',
        isCategory: true,
        icon: React.createElement(Globe, { className: "w-8 h-8 text-brand-blue" }),
        description: "Register domains or start your own domain reseller business.",
        content: "Secure your online identity with our comprehensive domain registration and reseller services.",
        subServices: [
            { 
                name: "Domain Registration", 
                path: "/web-hosting/domains/domain-registration",
                icon: React.createElement(Globe, { className: "w-6 h-6 text-brand-blue" }),
                description: "Secure your online identity by registering your perfect domain name."
            },
            { 
                name: "Domain Reseller", 
                path: "/web-hosting/domains/domain-reseller",
                icon: React.createElement(Users, { className: "w-6 h-6 text-brand-blue" }),
                description: "Start your own white-label domain business with our reseller platform."
            },
        ]
    },
    {
        name: 'Web Hosting',
        path: '/web-hosting',
        isCategory: true,
        icon: React.createElement(Database, { className: "w-8 h-8 text-brand-blue" }),
        description: "cPanel, WordPress & Reseller.",
        content: "Reliable, secure, and high-performance hosting for websites of all sizes.",
        subServices: [
            { name: "cPanel Hosting", path: "/web-hosting/cpanel-hosting", icon: React.createElement(Server, { className: "w-6 h-6 text-brand-blue" }), description: "Industry-standard control panel for easy website management." },
            { name: "cPanel Email Hosting", path: "/web-hosting/cpanel-email-hosting", icon: React.createElement(Cloud, { className: "w-6 h-6 text-brand-blue" }), description: "Professional, secure, and reliable email for your business domain." },
            { name: "DirectAdmin Hosting", path: "/web-hosting/directadmin-hosting", icon: React.createElement(Zap, { className: "w-6 h-6 text-brand-blue" }), description: "A lightweight and fast control panel for performance." },
            { name: "WordPress Hosting", path: "/web-hosting/wordpress-hosting", icon: React.createElement(CheckCircle, { className: "w-6 h-6 text-brand-blue" }), description: "Optimized hosting for the world's most popular CMS." },
            { name: "Reseller Hosting", path: "/web-hosting/reseller-hosting", icon: React.createElement(Users, { className: "w-6 h-6 text-brand-blue" }), description: "Start your own web hosting business under your brand." },
        ]
    },
    {
        name: 'Connectivity',
        path: '/connectivity',
        isCategory: true,
        icon: React.createElement(Wifi, { className: "w-8 h-8 text-brand-blue" }),
        description: "Fibre, LTE & 5G.",
        content: "High-speed internet solutions to power your business operations and growth.",
        subServices: [
            { 
                name: "LTE/5G", 
                path: "/connectivity/lte-5g",
                icon: React.createElement(Tower, { className: "w-6 h-6 text-brand-blue" }),
                description: "High-speed mobile broadband for primary or backup internet.",
                subServices: [
                    { 
                        name: "MTN", 
                        path: "/connectivity/lte-5g/mtn",
                        subServices: [
                            { name: "MTN Fixed 4G/5G Data", path: "/connectivity/lte-5g/mtn-fixed" },
                            { name: "MTN Mobile 4G/5G Data", path: "/connectivity/lte-5g/mtn-mobile" },
                        ]
                    },
                    { 
                        name: "Telkom", 
                        path: "/connectivity/lte-5g/telkom",
                        subServices: [
                            { name: "Telkom 4G/5G Data SIM", path: "/connectivity/lte-5g/telkom-data-sim" },
                            { name: "Telkom One", path: "/connectivity/lte-5g/telkom-one" },
                        ]
                    },
                    { name: "Vodacom", path: "/connectivity/lte-5g/vodacom" },
                ]
            },
            { 
                name: "Fiber Internet", 
                path: "/connectivity/fiber-internet", 
                icon: React.createElement(Wifi, { className: "w-6 h-6 text-brand-blue" }),
                description: "Dedicated, uncapped business fibre for ultimate speed and reliability.",
                subServices: [
                    { name: "MTN Fiber", path: "/connectivity/fiber-internet/mtn" },
                    { name: "Vodacom Fiber", path: "/connectivity/fiber-internet/vodacom" },
                    { name: "OpenServe Fibre", path: "/connectivity/fiber-internet/openserve" },
                    { name: "Fiber To The Home", path: "/connectivity/fiber-internet/ftth" },
                    { name: "Fiber To The Business", path: "/connectivity/fiber-internet/fttb" },
                    { name: "Corporate Fiber", path: "/connectivity/fiber-internet/corporate" },
                ]
            },
        ]
    },
    {
        name: 'Partners',
        path: '/partners',
        isCategory: true,
        icon: React.createElement(Users, { className: "w-8 h-8 text-brand-blue" }),
        description: "Agent, Reseller & Wholesale Programs.",
        content: "Leverage our network and solutions to grow your business.",
        subServices: [
            { name: 'Agents', path: '/partners/agents' },
            { name: 'Resellers', path: '/partners/resellers' },
            { 
                name: 'Wholesale', 
                path: '/partners/wholesale',
                subServices: [
                    { name: 'VoIP Billing Platform', path: '/partners/wholesale/billing-platform' },
                    { name: 'Wholesale Voice Rates', path: '/partners/wholesale/voice-rates' },
                    { name: 'Vodia Multi Tenant PBX', path: '/partners/wholesale/vodia-multi-tenant' },
                    { name: 'VitalPBX Multi Tenant PBX', path: '/partners/wholesale/vitalpbx-multi-tenant' },
                    { name: 'Bicom Multi Tenant PBX', path: '/partners/wholesale/bicom-multi-tenant' }
                ]
            },
        ]
    },
    { name: 'Coverage Check', path: '/coverage-check' },
    { name: 'Contact', path: '/contact' },
];

const getCategory = (path: string) => navStructure.find(item => item.path === path);

export const servicesCategory = getCategory('/services');
export const hostingCategory = getCategory('/web-hosting');
export const connectivityCategory = getCategory('/connectivity');
export const domainsCategory = getCategory('/web-hosting/domains');
export const hostedPbxCategory = getCategory('/services/hosted-pbx');
